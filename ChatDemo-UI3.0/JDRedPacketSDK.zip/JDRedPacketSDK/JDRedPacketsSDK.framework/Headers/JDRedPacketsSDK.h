//
//  JDRedPacketsSDK.h
//  JDRedPacketsSDK
//
//  Created by yanqi on 2016/10/21.
//  Copyright © 2016年 JDFinance. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JDRPApiObject.h"

//专属红包联系人回调
typedef void (^JDRPMemberBlock)(NSArray *);

//抢红包或发送红包成功消息回调
typedef void(^JDRPCompletionBlock)(NSDictionary *resultDic);

//把签名传给红包sdk
typedef void(^JDRPFetchBlock)(NSString *sign);

//result为NO时，说明token失效后需要重新接入方重新传入签名，通过fetchBlock将签名数据传给sdk
typedef void(^JDRPExpiryBlock)(BOOL result,JDRPFetchBlock fetchBlock);

@protocol JDRedPacketsDelegate <NSObject>

@optional
/**
 *  专属红包选择联系人调用方法（专属红包必须调用，需要接入方做从currentVC跳转进选择联系人页面，然后选择联系人后返回currentVC并传回选择的人员信息数组，未选择传nil）
 *
 *  @param currentVC 专属红包当前viewController
 *  @param limitCount 专属红包当前限制可选择的人数
 *  @param block JDRPMemberBlock返回为数组，数组成员为字典，字典中包括（userId:专属用户ID,userName：专属用户昵称,avatar：专属用户头像）
 */
- (void)getMemberAvatarsWithCurrentVC:(UIViewController *)currentVC
                      andLimitMembers:(NSInteger)limitCount
                      completionBlock:(JDRPMemberBlock)block;


/**
 红包主页-发红包-调起通讯录

 @param currentVC 当前的viewController
 @param block 是否已选择红包接收者（回调YES时，sdk会通过showHomePageWithSendBlock将红包信息回调给接入方）
 */

- (void)sendRedPacketWithCurrentVC:(UIViewController *)currentVC
                   completionBlock:(void(^)(BOOL didSelect))block;

@end


@interface JDRedPacketsSDK : NSObject

@property (nonatomic, weak) id<JDRedPacketsDelegate>        delegate;   //!<红包业务代理

+ (instancetype)sharedInstance;


/**
 初始化sdk

 @param paramsInfo 基本参数
 @param block token失效后重新获取签名，通过fetchBlock将签名数据传给sdk
 */
- (void)initSDK:(JDRPBasicParamsInfo *)paramsInfo
    expiryBlock:(JDRPExpiryBlock)block;

/**
 *  发红包
 *
 *  @param redpkgType   发红包界面类型 JDRPRedpacketType
 *  @param redpkgEntity 发红包数据对象 JDRPSendRedPacketsEntity
 *  @param block        发红包成功回调(resultDic参数定义如下)
 *
 *  resultDic  -----------------------------------------------
 *              redpkgId        NSString    红包 ID
 *              title           NSString    红包标题
 *              content         NSString    红包内容
 *              redpkgExtType   NSString    红包扩展类型（person:个人红包；group:群红包；reward：打赏红包；exclusive：专属红包）
 *            -----------------------------------------------
 */
- (void)sendRedPackets:(JDRPRedpacketType)redpkgType
          redpkgEntity:(JDRPSendRedPacketsEntity *)redpkgEntity
       completionBlock:(JDRPCompletionBlock)block;

/**
 *  抢红包接口
 *
 *  @param entity   抢红包时传入的数据对象
 *  @param block    抢红包成功回调(resultDic参数定义如下)
 *
 *  resultDic  -----------------------------------------------
 *              hasGrab         BOOL        是否抢到
 *              revAmount       NSString    领取金额(单位：分)
 *              grabFinish      BOOL        是否已抢完
 *              redpkgDesc      NSString    红包描述
 *              senderUserId    NSString    红包发送者用户ID
 *             -----------------------------------------------
 */
- (void)grabRedPacket:(JDRPGrabRedPacketEntity *)entity
      completionBlock:(JDRPCompletionBlock)block;

/**
 红包主页

 @param block 发红包成功回调(resultDic参数参考发红包回调参数定义)
 */
- (void)showHomePageWithSendBlock:(JDRPCompletionBlock)block;


/**
 余额界面
 */
- (void)showAccountPage;

/**
 获取当前红包SDK的版本号

 @return 返回当前红包SDK的版本号
 */
- (NSString *)getVersion;

/**
 *  关闭红包服务，清除基本参数信息缓存数据
 */
- (void)closeJDRPService;

@end
