//
//  JDRPApiObject.h
//  JDRedPacketsSDK
//
//  Created by yanqi on 2016/10/27.
//  Copyright © 2016年 JDFinance. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    /**
     *  单聊个人红包
     */
    JDRPRedpacketTypeSingle = 1,
    /**
     *  群组红包 （包含普通/拼手气红包和专属红包,默认普通红包）
     */
    JDRPRedpacketTypeGroup,
    /**
     *  群组普通红包（群组红包只展示普通/拼手气红包,默认普通红包）
     */
    JDRPRedpacketTypeGroupAvg,
    /**
     *  群组拼手气红包（群组红包只展示普通/拼手气红包,默认拼手气红包）
     */
    JDRPRedpacketTypeGroupRand,
    /**
     *  普通红包
     */
    JDRPRedpacketTypeAvg,
    /**
     *  拼手气红包
     */
    JDRPRedpacketTypeRand,
    /**
     *  专属红包（群组红包只展示专属,专属红包需要回调getMemberAvatarsWithCurrentVC返回专属人员信息）
     */
    JDRPRedpacketTypeMember,
    /**
     *  打赏红包（对个人进行打赏）
     */
    JDRPRedpacketTypeReward
}JDRPRedpacketType;


@interface JDRPBasicParamsInfo : NSObject

@property (nonatomic, copy)     NSString     *platformUserName;      //!<当前用户昵称
@property (nonatomic, copy)     NSString     *platformHeadImg;       //!<当前用户头像
@property (nonatomic, copy)     NSString     *sign;                  //!<签名信息
@property (nonatomic, strong)   NSDictionary *riskInfo;              //!<风控信息

@end

/**
 *  发红包第三方需传入所有数据对象
 *  个人发红包数据对象（targetUserId,目标用户ID）
 *  群发红包需传数据字段包括（groupNum,群人数;groupId,群ID）
 *  打赏红包需传数据字段包括（rewardUserId,目标用户ID;rewardUserName,目标用户昵称;rewardAvatar,目标用户头像）
 */
@interface JDRPSendRedPacketsEntity : NSObject

/**
 *  个人发红包数据对象（targetUserId,目标用户ID）
 */
@property (nonatomic, copy)     NSString     *targetUserId;      //!<红包接收者用户id
/**
 *  群发红包需传数据字段包括（groupNum,群人数;groupId,群ID）
 */
@property (nonatomic, assign)   NSInteger    groupNum;           //!<群人数
@property (nonatomic, copy)     NSString     *groupId;            //!<群ID

/**
 *  打赏红包需传数据字段包括（rewardUserId,目标用户ID;rewardUserName,目标用户昵称;rewardAvatar,目标用户头像）
 */
@property (nonatomic, copy)     NSString     *rewardUserId;      //!<打赏红包接收者用户id
@property (nonatomic, copy)     NSString     *rewardUserName;    //!<打赏红包接收者用户昵称
@property (nonatomic, copy)     NSString     *rewardAvatar;      //!<打赏红包接收者用户头像
@property (nonatomic, copy)     NSString     *rewardDesc;        //!<打赏原因描述

@end


/**
 *  抢红包第三方需传入所有数据对象
 *  注：参数必传
 */
@interface JDRPGrabRedPacketEntity : NSObject
@property (nonatomic, copy)     NSString     *redpkgId;             //!<红包ID
@property (nonatomic, copy)     NSString     *senderUserId;         //!<红包发送者用户ID
@property (nonatomic, copy)     NSString     *redpkgExtType;        //!<红包扩展类型
@property (nonatomic, copy)     NSString     *platformUserName;     //!<平台用户昵称
@property (nonatomic, copy)     NSString     *platformHeadImg;      //!<平台用户头像

@end
