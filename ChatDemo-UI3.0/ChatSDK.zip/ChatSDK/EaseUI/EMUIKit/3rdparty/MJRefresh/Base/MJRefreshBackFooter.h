//
//  MJRefreshBackFooter.h
//  MJRefreshExample
//
//  Created by MJ Lee on 15/4/24.
//

#import "MJRefreshFooter.h"

@interface MJRefreshBackFooter : MJRefreshFooter

@end
