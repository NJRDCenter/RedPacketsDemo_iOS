/************************************************************
 *  * Hyphenate CONFIDENTIAL
 * __________________
 * Copyright (C) 2016 Hyphenate Inc. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Hyphenate Inc.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Hyphenate Inc.
 */

#ifndef ChatDemo_UI2_0_EMCDDeviceManager_h
#define ChatDemo_UI2_0_EMCDDeviceManager_h

#import "EMCDDeviceManager+Media.h"
#import "EMCDDeviceManager+Remind.h"
#import "EMCDDeviceManager+Microphone.h"
#import "EMCDDeviceManager+ProximitySensor.h"

#endif
