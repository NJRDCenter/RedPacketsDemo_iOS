//
//  TransferCell.h
//  ChatDemo-UI3.0
//
//  Created by Mr.Yan on 16/8/25.
//  Copyright © 2016年 Mr.Yan. All rights reserved.
//

#import "EaseBaseMessageCell.h"

@interface TransferCell : EaseBaseMessageCell

@end
