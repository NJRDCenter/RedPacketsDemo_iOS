//
//  EaseRedBagCell.h
//  ChatDemo-UI3.0
//
//  Created by Mr.Yang on 16/2/23.
//




#import "EaseBubbleView+RedPacket.h"
#import "EaseBaseMessageCell.h"


/**
 *  红包显示的Cell
 */
@interface EaseRedBagCell : EaseBaseMessageCell


@end
